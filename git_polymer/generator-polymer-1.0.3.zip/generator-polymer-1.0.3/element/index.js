// alias yo polymer:el and yo polymer:element
module.exports = require('../el');
